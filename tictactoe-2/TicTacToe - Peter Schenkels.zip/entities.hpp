#pragma once

enum class TicTacToeEntities : char
{
    empty = '-',
    player_1 = 'x',
    player_2 = 'O'
};
